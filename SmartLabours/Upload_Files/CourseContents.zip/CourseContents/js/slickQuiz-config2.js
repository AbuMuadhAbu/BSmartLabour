// Setup your quiz text and questions here

// NOTE: pay attention to commas, IE struggles with those bad boys

var quizJSON = {
    "info": {
        "name":    "",
        "main":    "",
    },
    "questions": [
        { // Question 1 - Multiple Choice, Single True Answer
            "q": "What kind of movie does Mahesh want to see?",
            "a": [
                {"option": "Action",             "correct": false},
                {"option": "Thriller",                    "correct": true},
                {"option": "Comedy",                      "correct": false},
            ],
            "correct": "<span>That's right!</span><p>Good job!</p>",
            "incorrect": "<span>That's incorrect</span> <p>Go through the lessons again</p>" // no comma here
        },
        { // Question 2 - Multiple Choice, Single True Answer, Select Any
            "q": "Which show does he plan to watch?",
            "a": [
                {"option": "Morning",                     "correct": false},
                {"option": "Noon",                      "correct": false},
                {"option": "Evening",                      "correct": true},
                {"option": "Late night?",                      "correct": false},
            ],
            "select_any": true,
            "correct": "<span>That's right!</span><p>Good job!</p>",
            "incorrect": "<span>That's incorrect</span> <p>Go through the lessons again</p>" // no comma here
        },
        { // Question 3 - Multiple Choice, Single True Answer, Select Any
            "q": "How many tickets is he likely to buy?",
            "a": [
                {"option": "Two",        "correct": true},
                {"option": "Four",          "correct": false},
                {"option": "Six",            "correct": false},
            ],
            "select_any": true,
            "correct": "<span>That's right!</span><p>Good job!</p>",
            "incorrect": "<span>That's incorrect</span> <p>Go through the lessons again</p>" // no comma here
        },
        { // Question 3 - Multiple Choice, Single True Answer, Select Any
            "q": "Which row does he want to be seated on?",
            "a": [
                {"option": "Back",        "correct": false},
                {"option": "Front",          "correct": false},
                {"option": "Middle",            "correct": true},
            ],
            "select_any": true,
            "correct": "<span>That's right!</span><p>Good job!</p>",
            "incorrect": "<span>That's incorrect</span> <p>Go through the lessons again</p>" // no comma here
        }
    ]
};
