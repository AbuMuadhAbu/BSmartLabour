// Setup your quiz text and questions here

// NOTE: pay attention to commas, IE struggles with those bad boys

var quizJSON = {
    "info": {
        "name":    "",
        "main":    "",
    },
    "questions": [
        { // Question 1 - Multiple Choice, Single True Answer
            "q": "Savlon soap is ------------- than Dettol soap.",
            "a": [
                {"option": "More expensive",             "correct": false},
                {"option": "Cheaper",                    "correct": true},
                {"option": "Cheap",                      "correct": false},
            ],
            "correct": "<span>That's right!</span><p>Good job!</p>",
            "incorrect": "<span>That's incorrect</span> <p>Go through the lessons again</p>" // no comma here
        },
        { // Question 2 - Multiple Choice, Single True Answer, Select Any
            "q": "What is the  ---------- of the soap?",
            "a": [
                {"option": "Price",                     "correct": true},
                {"option": "Cost",                      "correct": true},
                {"option": "Time",                      "correct": false},
            ],
            "select_any": true,
            "correct": "<span>That's right!</span><p>Good job!</p>",
            "incorrect": "<span>That's incorrect</span> <p>Go through the lessons again</p>" // no comma here
        },
        { // Question 3 - Multiple Choice, Single True Answer, Select Any
            "q": "Where will you buy a bar of soap?",
            "a": [
                {"option": "At the local store",        "correct": true},
                {"option": "At the butcher shop",          "correct": false},
                {"option": "At the bookstore",            "correct": false},
            ],
            "select_any": true,
            "correct": "<span>That's right!</span><p>Good job!</p>",
            "incorrect": "<span>That's incorrect</span> <p>Go through the lessons again</p>" // no comma here
        }
    ]
};
