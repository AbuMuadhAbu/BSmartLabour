// Setup your quiz text and questions here

// NOTE: pay attention to commas, IE struggles with those bad boys

var quizJSON = {
    "info": {
        "name":    "",
        "main":    "",
    },
    "questions": [
        { // Question 1 - Multiple Choice, Single True Answer
            "q": "When you meet your friend, say:",
            "a": [
                {"option": "Hello",                 "correct": false},
                {"option": "Hi",                    "correct": true},
                {"option": "Good afternoon",        "correct": false},
            ],
            "correct": "<span>That's right!</span><p>Good job!</p>",
            "incorrect": "<span>That's incorrect</span> <p>Go through the lessons again</p>" // no comma here
        },
        { // Question 2 - Multiple Choice, Single True Answer, Select Any
            "q": "Have a ---------- day",
            "a": [
                {"option": "Nice",                  "correct": true},
                {"option": "Bad",                   "correct": false},
                {"option": "Cheerful",              "correct": false},
            ],
            "select_any": true,
            "correct": "<span>That's right!</span><p>Good job!</p>",
            "incorrect": "<span>That's incorrect</span> <p>Go through the lessons again</p>" // no comma here
        },
        { // Question 3 - Multiple Choice, Single True Answer, Select Any
            "q": "How do you greet someone at 9 pm?",
            "a": [
                {"option": "Good Day",              "correct": false},
                {"option": "Good Evening",          "correct": true},
                {"option": "Good Night",            "correct": false},
            ],
            "select_any": true,
            "correct": "<span>That's right!</span><p>Good job!</p>",
            "incorrect": "<span>That's incorrect</span> <p>Go through the lessons again</p>" // no comma here
        },
        { // Question 4
            "q": "When leaving, what do you say?",
            "a": [
                {"option": "Good Night",            "correct": true},
                {"option": "Good Evening",          "correct": false},
                {"option": "Good Afternoon",        "correct": false},
            ],
            "correct": "<span>That's right!</span><p>Good job!</p>",
            "incorrect": "<span>That's incorrect</span> <p>Go through the lessons again</p>" // no comma here
        }
    ]
};
